import { IncomingMessage, ServerResponse } from "node:http";
//#region src/shared/contracts.d.ts
declare const DEVICE_SCOPES: readonly ["chat.read", "chat.write", "files.read", "files.write", "files.delete", "settings.read", "settings.write"];
type DeviceScope = (typeof DEVICE_SCOPES)[number];
interface RootView {
  id: string;
  label: string;
  createdAt: number;
}
interface DeviceView {
  id: string;
  name: string;
  scopes: DeviceScope[];
  rootIds: string[];
  createdAt: number;
  lastSeenAt?: number;
  revokedAt?: number;
}
interface FileEntryView {
  name: string;
  path: string;
  kind: 'file' | 'directory' | 'symlink' | 'other';
  size: number;
  modifiedAt: number;
  writable: boolean;
}
interface WorkspaceEvent {
  id: string;
  type: string;
  time: number;
  data: Record<string, unknown>;
}
interface AdminPrincipal {
  kind: 'admin';
  id: 'loopback-admin';
  scopes: ReadonlySet<DeviceScope>;
  rootIds: 'all';
}
interface DevicePrincipal {
  kind: 'device';
  id: string;
  name: string;
  scopes: ReadonlySet<DeviceScope>;
  rootIds: ReadonlySet<string>;
}
type Principal = AdminPrincipal | DevicePrincipal;
//#endregion
//#region src/host/database.d.ts
interface StoredRoot extends RootView {
  realPath: string;
}
interface AuthenticatedDevice extends DeviceView {
  tokenHash: string;
}
interface TrashRecord {
  id: string;
  rootId: string;
  relativePath: string;
  payloadPath: string;
  kind: string;
  size: number;
  digest: string;
  createdAt: number;
  status: string;
}
declare class WorkspaceDatabase {
  readonly dataDir: string;
  readonly trashDir: string;
  private readonly db;
  constructor(dataDir: string);
  close(): void;
  getSetting(key: string): string | undefined;
  setSetting(key: string, value: string): void;
  addRoot(inputPath: string, label?: string): Promise<StoredRoot>;
  listRoots(): StoredRoot[];
  getRoot(id: string): StoredRoot | undefined;
  removeRoot(id: string): void;
  createPairing(rootIds: string[], scopes: DeviceScope[], ttlMs?: number): {
    code: string;
    expiresAt: number;
  };
  exchangePairing(code: string, deviceName: string): {
    token: string;
    device: DeviceView;
  };
  authenticate(token: string): AuthenticatedDevice | undefined;
  getActiveDevice(id: string): AuthenticatedDevice | undefined;
  private hydrateDevice;
  listDevices(): DeviceView[];
  isDeviceActive(id: string): boolean;
  updateDevice(id: string, scopes: DeviceScope[], rootIds: string[]): DeviceView;
  revokeDevice(id: string): void;
  insertTrash(record: TrashRecord): void;
  updateTrashStatus(id: string, status: string): void;
  getTrash(id: string): TrashRecord | undefined;
  listTrash(rootIds?: ReadonlySet<string>): TrashRecord[];
  deleteTrashRecord(id: string): void;
  audit(actorType: string, actorId: string, action: string, rootId?: string, relativePath?: string, details?: Record<string, unknown>, requestId?: string): void;
  listAudit(limit?: number): Record<string, unknown>[];
  readIdempotent(deviceId: string, key: string): {
    status: number;
    body: unknown;
  } | undefined;
  saveIdempotent(deviceId: string, key: string, status: number, body: unknown): void;
  private migrate;
}
//#endregion
//#region src/host/chat-adapter.d.ts
interface RpcResponse<T> {
  result: {
    ok: true;
    value: T;
  } | {
    ok: false;
    error: {
      code: string;
      message: string;
      details?: unknown;
    };
  };
}
interface DshApiProxy {
  respond(message: {
    type: 'client-response';
    rpcId: string;
    result: {
      ok: true;
      value: unknown;
    };
  }): Promise<{
    accepted: true;
  } | {
    accepted: false;
    reason: 'not-pending' | 'bad-response';
  }>;
  sessions: {
    list(request: {
      rpcId: string;
      payload: {
        cursor?: string;
      };
    }): Promise<RpcResponse<{
      items: DshSessionSummary[];
    }>>;
    create(request: {
      rpcId: string;
      payload: {
        cwd?: string;
        workspaceId?: string;
        sessionId?: string;
        agentPreset?: string;
      };
    }): Promise<RpcResponse<{
      sessionId: string;
      agentPreset?: string;
    }>>;
    history(request: {
      rpcId: string;
      payload: {
        sessionId: string;
        beforeSeq?: number;
        maxMessages?: number;
      };
    }): Promise<RpcResponse<{
      events: unknown[];
      hasMore: boolean;
      projections?: unknown;
    }>>;
    prompt(request: {
      rpcId: string;
      payload: {
        sessionId: string;
        mode: 'queue' | 'steer';
        content: {
          type: 'text';
          text: string;
        }[];
        clientTimeZone?: string;
      };
    }): Promise<RpcResponse<{
      accepted: true;
      command?: unknown;
    }>>;
    cancel(request: {
      rpcId: string;
      payload: {
        sessionId: string;
      };
    }): Promise<RpcResponse<{
      accepted: true;
    }>>;
    rename(request: {
      rpcId: string;
      payload: {
        sessionId: string;
        title: string;
      };
    }): Promise<RpcResponse<{
      title: string;
      seq: number;
    }>>;
    fork(request: {
      rpcId: string;
      payload: {
        sessionId: string;
        atSeq?: number;
      };
    }): Promise<RpcResponse<{
      sessionId: string;
    }>>;
    models(request: {
      rpcId: string;
      payload: {
        sessionId: string;
      };
    }): Promise<RpcResponse<SessionModelsView>>;
    selectModel(request: {
      rpcId: string;
      payload: {
        sessionId: string;
        provider: string;
        model: string;
        reasoningEffort?: string;
      };
    }): Promise<RpcResponse<{
      selected: ModelSelectionView;
    }>>;
  };
  workspace: {
    list(request: {
      rpcId: string;
      payload: Record<string, never>;
    }): Promise<RpcResponse<{
      items: DshWorkspaceSummary[];
      archivedSessionIds: string[];
    }>>;
    create(request: {
      rpcId: string;
      payload: {
        path: string;
      };
    }): Promise<RpcResponse<{
      workspace: DshWorkspaceSummary;
      created: boolean;
    }>>;
    rename(request: {
      rpcId: string;
      payload: {
        workspaceId: string;
        title: string;
      };
    }): Promise<RpcResponse<{
      workspace: DshWorkspaceSummary;
    }>>;
    delete(request: {
      rpcId: string;
      payload: {
        workspaceId: string;
      };
    }): Promise<RpcResponse<{
      deleted: true;
    }>>;
    archiveSession(request: {
      rpcId: string;
      payload: {
        sessionId: string;
      };
    }): Promise<RpcResponse<{
      archivedSessionIds: string[];
    }>>;
  };
  agentPresets: {
    list(request: {
      rpcId: string;
      payload: Record<string, never>;
    }): Promise<RpcResponse<{
      presets: DshAgentPresetSummary[];
      authorable: boolean;
      hasDocument: boolean;
    }>>;
    select(request: {
      rpcId: string;
      payload: {
        sessionId: string;
        agentPreset: string;
      };
    }): Promise<RpcResponse<{
      agentPreset: string;
    }>>;
  };
  events: {
    mux(request: {
      rpcId: string;
      payload: Record<string, never>;
    }, signal: AbortSignal): AsyncIterable<{
      rpcId: string;
      payload: Record<string, unknown>;
    }>;
    host(request: {
      rpcId: string;
      payload: Record<string, never>;
    }, signal: AbortSignal): AsyncIterable<{
      rpcId: string;
      payload: Record<string, unknown>;
    }>;
  };
}
interface ModelSelectionView {
  provider: string;
  model: string;
  reasoningEffort?: string;
}
interface ModelReasoningView {
  efforts: {
    id: string;
    name: string;
    description?: string;
  }[];
  defaultEffort?: string;
}
interface ModelProviderGroupView {
  id: string;
  name: string;
  models: {
    id: string;
    name: string;
    description?: string;
    contextWindow?: number;
    maxTokens?: number;
    reasoning?: ModelReasoningView;
  }[];
}
interface SessionModelsView {
  current: ModelSelectionView;
  routable: boolean;
  groups: ModelProviderGroupView[];
  failures: {
    provider: string;
    message: string;
  }[];
}
interface CommandDescriptorView {
  name: string;
  description: string;
  input?: {
    hint: string;
  };
}
interface CommandExecutionView {
  commandId: string;
  result: {
    kind: 'success' | 'error';
    text?: string;
    sourceEventSeq?: number;
  };
}
interface DshCommandRuntime {
  list(agent: unknown): readonly CommandDescriptorView[];
  execute(agent: unknown, line: string, signal: AbortSignal): Promise<CommandExecutionView | undefined>;
}
interface DshAgentRegistry {
  get(sessionId: string): unknown | undefined;
}
interface DshCommandServices {
  commands: DshCommandRuntime;
  agents: DshAgentRegistry;
}
interface DshSessionSummary {
  sessionId: string;
  updatedAt: number;
  running: boolean;
  blank: boolean;
  cwd?: string;
  agentPreset?: string;
  parentSessionId?: string;
  origin?: 'subagent';
  projections?: {
    asOfSeq: number;
    values: Record<string, unknown>;
  };
}
interface DshWorkspaceSummary {
  workspaceId: string;
  path: string;
  title: string;
  sessionIds: string[];
  createdAt: string;
  updatedAt: string;
}
interface DshAgentPresetSummary {
  id: string;
  trust: 'system' | 'user';
  isDefault: boolean;
  name?: string;
  description?: string;
  broken?: string;
}
interface ChatSessionView {
  id: string;
  rootId: string;
  cwd: string;
  updatedAt: number;
  running: boolean;
  blank: boolean;
  title?: string;
  workspaceId?: string;
  workspaceTitle?: string;
  agentPreset?: string;
  parentSessionId?: string;
  origin?: 'subagent';
  pendingInteraction?: 'approval';
}
interface PendingApprovalView {
  id: string;
  sessionId: string;
  toolName: string;
  reason?: string;
  detail?: string;
  risk: 'standard' | 'full-access';
  requestedAt: number;
}
interface ChatWorkspaceView {
  id: string;
  title: string;
  rootId: string;
  path: string;
  createdAt: string;
  updatedAt: string;
}
interface AgentPresetView {
  id: string;
  name: string;
  description?: string;
  trust: 'system' | 'user';
  isDefault: boolean;
  available: boolean;
}
declare class DshChatAdapter {
  private readonly api;
  private readonly database;
  private readonly commandServices?;
  private readonly sessionRootIds;
  private readonly sessionRootLookups;
  private readonly pendingApprovals;
  constructor(api: DshApiProxy, database: WorkspaceDatabase, commandServices?: DshCommandServices | undefined);
  listSessions(principal: Principal): Promise<ChatSessionView[]>;
  listWorkspaces(principal: Principal): Promise<ChatWorkspaceView[]>;
  createWorkspace(principal: Principal, rootId: string, relativePath: string): Promise<ChatWorkspaceView>;
  renameWorkspace(principal: Principal, workspaceId: string, title: string): Promise<ChatWorkspaceView>;
  deleteWorkspace(principal: Principal, workspaceId: string): Promise<void>;
  listAgentPresets(): Promise<AgentPresetView[]>;
  selectAgentPreset(principal: Principal, sessionId: string, agentPreset: string): Promise<string>;
  createSessionInWorkspace(principal: Principal, workspaceId: string, options: {
    sessionId?: string;
    agentPreset?: string;
  }): Promise<{
    id: string;
    agentPreset?: string;
  }>;
  createSession(principal: Principal, rootId: string, relativePath: string, options: {
    sessionId?: string;
    agentPreset?: string;
  }): Promise<{
    id: string;
    agentPreset?: string;
  }>;
  history(principal: Principal, sessionId: string, options: {
    beforeSeq?: number;
    maxMessages?: number;
  }): Promise<{
    events: unknown[];
    hasMore: boolean;
    projections?: unknown;
  }>;
  prompt(principal: Principal, sessionId: string, text: string, mode: 'queue' | 'steer', clientTimeZone?: string): Promise<{
    accepted: true;
    command?: unknown;
  }>;
  cancel(principal: Principal, sessionId: string): Promise<void>;
  renameSession(principal: Principal, sessionId: string, title: string): Promise<{
    title: string;
    seq: number;
  }>;
  forkSession(principal: Principal, sessionId: string, atSeq?: number): Promise<string>;
  archiveSession(principal: Principal, sessionId: string): Promise<string[]>;
  listPendingApprovals(principal: Principal, sessionId: string): Promise<PendingApprovalView[]>;
  decideApproval(principal: Principal, sessionId: string, approvalId: string, outcome: 'allowed-once' | 'rejected'): Promise<PendingApprovalView>;
  models(principal: Principal, sessionId: string): Promise<SessionModelsView>;
  selectModel(principal: Principal, sessionId: string, selection: ModelSelectionView): Promise<ModelSelectionView>;
  listCommands(principal: Principal, sessionId: string): Promise<CommandDescriptorView[]>;
  executeCommand(principal: Principal, sessionId: string, line: string): Promise<CommandExecutionView>;
  isSessionAuthorized(principal: Principal, sessionId: string): Promise<boolean>;
  startEvents(signal: AbortSignal, emit: (event: WorkspaceEvent) => void): void;
  private captureApproval;
  private hasPendingApproval;
  private commandAgent;
  private requireSession;
  private requireWorkspace;
  private visibleWorkspaces;
  private requireAuthorizedRoot;
  private authorizedRoots;
  private sessionRootId;
}
//#endregion
//#region src/host/rate-limit.d.ts
declare class FixedWindowLimiter {
  private readonly limit;
  private readonly windowMs;
  private readonly buckets;
  constructor(limit: number, windowMs: number);
  consume(key: string): void;
  private sweep;
}
//#endregion
//#region src/host/auth.d.ts
declare class AuthService {
  private readonly database;
  private readonly authFailures;
  readonly pairingAttempts: FixedWindowLimiter;
  readonly requests: FixedWindowLimiter;
  constructor(database: WorkspaceDatabase);
  principal(req: IncomingMessage, options?: {
    allowAdmin?: boolean;
  }): Principal;
  requireAdmin(req: IncomingMessage): Principal;
  requireScope(principal: Principal, scope: DeviceScope): void;
  requireRoot(principal: Principal, rootId: string): void;
}
//#endregion
//#region src/host/event-bus.d.ts
declare class WorkspaceEventBus {
  private readonly listeners;
  emit(event: WorkspaceEvent): void;
  subscribe(listener: (event: WorkspaceEvent) => void): () => void;
}
//#endregion
//#region src/host/file-service.d.ts
interface DirectoryPage {
  path: string;
  entries: FileEntryView[];
  nextCursor?: string;
}
interface ContentDescriptor {
  absolutePath: string;
  size: number;
  modifiedAt: number;
  etag: string;
  contentType: string;
}
interface TrashView {
  id: string;
  rootId: string;
  path: string;
  kind: string;
  size: number;
  createdAt: number;
  status: string;
}
type EventSink = (event: WorkspaceEvent) => void;
declare class FileService {
  private readonly database;
  private readonly emit;
  constructor(database: WorkspaceDatabase, emit: EventSink);
  list(root: StoredRoot, relativePath: string, limit?: number, cursor?: string): Promise<DirectoryPage>;
  inspectContent(root: StoredRoot, relativePath: string): Promise<ContentDescriptor>;
  streamContent(descriptor: ContentDescriptor, range?: {
    start: number;
    end: number;
  }): import("fs").ReadStream;
  writeContent(root: StoredRoot, relativePath: string, content: Uint8Array, conditions: {
    ifMatch?: string;
    ifNoneMatch?: string;
  }): Promise<{
    etag: string;
    size: number;
    modifiedAt: number;
  }>;
  createEntry(root: StoredRoot, relativePath: string, kind: 'file' | 'directory'): Promise<FileEntryView>;
  moveEntry(root: StoredRoot, sourcePath: string, destinationPath: string): Promise<void>;
  trashEntry(root: StoredRoot, relativePath: string): Promise<TrashView>;
  listTrash(rootIds?: ReadonlySet<string>): TrashView[];
  restoreTrash(root: StoredRoot, trashId: string): Promise<void>;
  purgeTrash(trashId: string): Promise<void>;
  private notify;
}
//#endregion
//#region src/host/settings-adapter.d.ts
interface SettingsNamespaceView {
  ns: string;
  schema?: unknown;
  value: unknown;
  base?: unknown;
  user?: unknown;
  revision: number;
}
interface ConfigurableProvider {
  provider: string;
  displayName: string;
  settingsNs: string;
  settingsPath: string[];
  active: boolean;
  declared?: boolean;
}
interface SettingsApiProxy extends DshApiProxy {
  settings: {
    describe(request: {
      rpcId: string;
      payload: Record<string, never>;
    }): Promise<RpcResponse<{
      writable: boolean;
      hasDocument: boolean;
      namespaces: SettingsNamespaceView[];
    }>>;
    mutate(request: {
      rpcId: string;
      payload: {
        ns: string;
        ops: Array<{
          op: 'set';
          path: string[];
          value: unknown;
        } | {
          op: 'unset';
          path: string[];
        }>;
        expectedRevision?: number;
      };
    }): Promise<RpcResponse<SettingsNamespaceView>>;
  };
  credentials: {
    describe(request: {
      rpcId: string;
      payload: {
        refs: string[];
      };
    }): Promise<RpcResponse<{
      credentials: Record<string, {
        configured: boolean;
        source?: string;
        writable: boolean;
      }>;
    }>>;
    set(request: {
      rpcId: string;
      payload: {
        ref: string;
        value: string;
      };
    }): Promise<RpcResponse<Record<string, never>>>;
    unset(request: {
      rpcId: string;
      payload: {
        ref: string;
      };
    }): Promise<RpcResponse<Record<string, never>>>;
  };
  llm: {
    providers(request: {
      rpcId: string;
      payload: Record<string, never>;
    }): Promise<RpcResponse<{
      providers: ConfigurableProvider[];
    }>>;
    models(request: {
      rpcId: string;
      payload: Record<string, never>;
    }): Promise<RpcResponse<{
      groups: ModelProviderGroupView[];
      failures: {
        provider: string;
        message: string;
      }[];
    }>>;
    discoverModels(request: {
      rpcId: string;
      payload: {
        settingsNs: string;
        provider?: string;
        baseURL?: string;
        api?: string;
        apiKey?: string;
      };
    }): Promise<RpcResponse<{
      models: ProviderModelView[];
    }>>;
  };
}
interface ProviderModelView {
  id: string;
  name?: string;
  contextWindow?: number;
  maxTokens?: number;
}
interface ProviderConfigView {
  baseURL?: string;
  api?: string;
  displayName?: string;
  thinking?: string;
  reasoningEffort?: string;
  models: ProviderModelView[];
  modelsInherited?: boolean;
}
interface ProviderView {
  id: string;
  displayName: string;
  active: boolean;
  declared?: boolean;
  configurable: boolean;
  configured: boolean;
  removable: boolean;
  credential: {
    ref: string;
    configured: boolean;
    source?: string;
    writable: boolean;
  };
  config: ProviderConfigView;
}
interface ProviderPatch {
  displayName?: string | null;
  baseURL?: string | null;
  api?: string | null;
  apiKey?: string | null;
  thinking?: string | null;
  reasoningEffort?: string | null;
  models?: ProviderModelView[];
  expectedRevision?: number;
}
interface CustomProviderCreate {
  id: string;
  displayName?: string;
  baseURL: string;
  api: string;
  apiKey?: string;
  models: ProviderModelView[];
  expectedRevision?: number;
}
interface CustomProviderCapability {
  available: boolean;
  protocols: string[];
  revision?: number;
}
declare class DshSettingsAdapter {
  private readonly api;
  constructor(api: SettingsApiProxy);
  listProviders(): Promise<{
    writable: boolean;
    revisionByNamespace: Record<string, number>;
    customProvider: CustomProviderCapability;
    providers: ProviderView[];
  }>;
  catalog(): Promise<{
    groups: ModelProviderGroupView[];
    failures: {
      provider: string;
      message: string;
    }[];
  }>;
  updateProvider(providerId: string, patch: ProviderPatch): Promise<void>;
  createProvider(input: CustomProviderCreate): Promise<void>;
  removeProvider(providerId: string, expectedRevision?: number): Promise<void>;
  discover(providerId: string, draft: {
    baseURL?: string;
    api?: string;
    apiKey?: string;
  }): Promise<ProviderModelView[]>;
  private providerContext;
}
//#endregion
//#region src/host/router.d.ts
interface RemoteOperationView {
  id: string;
  state: 'pending' | 'succeeded' | 'failed';
  targetHost: string;
  targetPort: number;
  code?: string;
  message?: string;
  pairingCode?: string;
  pairingExpiresAt?: number;
}
interface RemoteControl {
  status(operationId?: string): {
    host: string;
    port: number;
    configuredHost: string;
    configuredPort: number;
    remoteEnabled: boolean;
    operation?: RemoteOperationView;
  };
  enable(rootIds: string[], scopes: DeviceScope[]): RemoteOperationView;
  disable(): RemoteOperationView;
  configure(host: string, port: number): RemoteOperationView;
}
interface RouterOptions {
  database: WorkspaceDatabase;
  auth: AuthService;
  files: FileService;
  chat: DshChatAdapter;
  settings: DshSettingsAdapter;
  remote: RemoteControl;
  maxUploadBytes: number;
}
declare class ApiRouter {
  private readonly options;
  constructor(options: RouterOptions);
  handle(req: IncomingMessage, res: ServerResponse, stripPrefix?: string): Promise<void>;
  private dispatch;
  private dispatchManagement;
  private dispatchEntries;
  private dispatchContent;
  private requireRoot;
  private authorizedRoots;
  private audit;
  private readIdempotent;
  private saveIdempotent;
}
//#endregion
//#region src/host/server.d.ts
interface RemoteApiServerOptions {
  port: number;
  remoteHost?: string;
  database: WorkspaceDatabase;
  auth: AuthService;
  chat: DshChatAdapter;
  events: WorkspaceEventBus;
  handle: (req: IncomingMessage, res: ServerResponse) => Promise<void>;
}
declare class RemoteApiServer implements RemoteControl {
  private readonly options;
  private server;
  private host;
  private actualPort;
  private configuredHost;
  private configuredPort;
  private remoteEnabled;
  private readonly operations;
  private readonly sockets;
  private readonly webSockets;
  private readonly eventsAbort;
  private unsubscribeEvents;
  private broadcastQueue;
  private changing;
  constructor(options: RemoteApiServerOptions);
  start(): Promise<void>;
  stop(): Promise<void>;
  status(operationId?: string): {
    operation?: RemoteOperationView;
    host: string;
    port: number;
    configuredHost: string;
    configuredPort: number;
    remoteEnabled: boolean;
  };
  enable(rootIds: string[], scopes: DeviceScope[]): RemoteOperationView;
  disable(): RemoteOperationView;
  configure(host: string, port: number): RemoteOperationView;
  serveWorkspace(req: IncomingMessage, res: ServerResponse, options: {
    apiBase: string;
    manageBase: string;
    scriptUrl: string;
  }): Promise<void>;
  serveStandaloneScript(req: IncomingMessage, res: ServerResponse): Promise<void>;
  private scheduleChange;
  private performChange;
  private rebind;
  private bind;
  private createBoundServer;
  private closeCurrent;
  private handleUpgrade;
  private broadcast;
  private eventAllowed;
  private trimOperations;
}
declare function attachEmbeddedRoutes(webServer: {
  register(route: {
    kind: 'exact' | 'prefix';
    path: string;
    handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>;
  }): () => void;
}, router: ApiRouter, remote: RemoteApiServer): () => void;
//#endregion
//#region src/index.d.ts
declare const name = "dsh-workspace";
declare const inject: string[];
interface Config {
  dataDir?: string;
  port?: number;
  remoteHost?: string;
  maxUploadBytes?: number;
}
interface HostContext {
  apiProxy: ConstructorParameters<typeof DshChatAdapter>[0] & ConstructorParameters<typeof DshSettingsAdapter>[0];
  webServer: Parameters<typeof attachEmbeddedRoutes>[0];
  agents: NonNullable<ConstructorParameters<typeof DshChatAdapter>[2]>['agents'];
  commands: NonNullable<ConstructorParameters<typeof DshChatAdapter>[2]>['commands'];
  logger: {
    info(message: string): void;
    warn(error: Error): void;
  };
  effect(register: () => (() => void | Promise<void>), label?: string): void;
}
declare function apply(ctx: HostContext, config?: Config): Promise<void>;
//#endregion
export { Config, apply, apply as default, inject, name };